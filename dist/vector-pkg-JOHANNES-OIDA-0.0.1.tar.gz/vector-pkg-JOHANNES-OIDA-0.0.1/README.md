# Vector Package

ja ok meine lieben, das soll eine ausführliche beschreibung vom package sein.
in wirklichkeit gibts aber net viel zu sagen, außer dass es sich hier um ein package handelt, mit dem man vektoren erstellt.
bam oida.
